DROP TABLE IF EXISTS `#__imageshow_source_profile`;
DROP TABLE IF EXISTS `#__imageshow_images`;
DROP TABLE IF EXISTS `#__imageshow_log`;
DROP TABLE IF EXISTS `#__imageshow_showcase`;
DROP TABLE IF EXISTS `#__imageshow_showlist`;
DROP TABLE IF EXISTS `#__jsn_imageshow_messages`;
DROP TABLE IF EXISTS `#__jsn_imageshow_config`;
DROP TABLE IF EXISTS `#__imageshow_theme_profile`;